                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1252557
Forearm for InMoov Robot by PRopeG is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

These are the files needed for the forearm. Although some parts (like the servo bed) are based on Gael Langevin's InMoov design , most of them are original since I needed the forearm to hold the batteries, servos, Arduino, et cetera. The forearm may be divided in three main parts:

1. "Wrist Hook" & "Wrist": the first part provides the join with the hand and the latter, the wrist itself, has a support for a 9V battery and a series of holes that will guide the thread (fising line).
2. "Forearm Servos", "Forearm Servos Cover", "Servos bed" & "Thread guide": they hold the 5 servos and guide the fishing line from the servos to the finger tips.
3. "Forearm Arduino", "Forearm Arduino Cover" & "Arduino Support": it holds the 6V battery (that will suply the servos) and the Arduino board with its corresponding shield.


# Custom Section

<iframe src="//www.youtube.com/embed/rGSt7tQS0yg" frameborder="0" allowfullscreen></iframe>